//
//  LoadViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class LoadViewController: UIViewController {
    
    var users:[NSManagedObject] = []
    
//    func saveUser() -> Bool {
//        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
//
//        let context = appDelegate.persistentContainer.viewContext
//
//        if let entity = NSEntityDescription.entity(forEntityName: "User", in: context) {
//
//            let user = NSManagedObject(entity: entity, insertInto: context)
//
//            let userID = UUID().uuidString
//
//            user.setValue(userID, forKey: "userID")
//            user.setValue("Adrian", forKey: "firstName")
//            user.setValue("Filipe", forKey: "lastName")
//            user.setValue("905-678-3456", forKey: "phone")
//            user.setValue("adrian-filipe@gmail.com", forKey: "email")
//            user.setValue("Adrian_1010", forKey: "password")
//            user.setValue("admin", forKey: "role")
//
//            do {
//                try context.save()
//                users.append(user)
//                print("Connected!")
//                return true
//            } catch let error as NSError {
//                print("Cannot connect!")
//                return false
//            }
//        }
//
//        return false
//    }
    
    override func viewDidLoad() {
//        super.viewDidLoad()
//        if saveUser() {
//            performSegue(withIdentifier: "LoadApp", sender: self)
//        }
    }
}
