//
//  LoadViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit

class LoadViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userDB.addUser(firstName: "Adrian", lastName: "Filipe", phone: "905-678-3456", email: "Adrian@gmail.com", password: "Adrian_1010", role: "admin")
        performSegue(withIdentifier: "LoadApp", sender: self)
        // Do any additional setup after loading the view.
    }
}
