//
//  RequestViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class RequestViewController: UIViewController {
    
    var requests:[NSManagedObject] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var lblRequestBox: UILabel!
    
    @IBOutlet weak var txtRequest: UITextField!
    
    @IBAction func btnSendRequest(_ sender: UIButton) {
        
        lblMessageBox.text = ""
        
//        let user = userDB.getUser(id: loginID)!
        
        if txtRequest.text != "" {
            
//            if requestDB.addRequest(userID: loginID, user: user, request: txtRequest.text!) {
            if saveRequest(userID: loginID, userFirstName: loginFirstName, userLastName: loginLastName, description: txtRequest.text!){
                
                if retrieveData() {
                    
                    var requestText = ""
                    
                    for request in requests {
                        
                        if request.value(forKey: "userID") as! String == loginID && request.value(forKey: "status") as! String == "sent" {
                            
                            requestText += request.value(forKey: "request") as! String + " "
                            
                            requestText += request.value(forKey: "date") as! String + "\n"
                        }
                    }
                    
                    lblRequestBox.text = requestText
                    
                    lblMessageBox.text = "Request sent!"
                }
                    
                else {
                    lblMessageBox.text = "Error! Could not load data!"
                }
                
                txtRequest.text = ""
            }
            
            else {
                lblMessageBox.text = "Error! Could not send request"
            }
            
        }
    }
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    @IBOutlet weak var lblResponseBox: UILabel!
    
    func retrieveData() -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        let connect = NSFetchRequest<NSManagedObject>(entityName: "Request")
        
        do {
            self.requests = try context.fetch(connect)
            print("Connected!")
            return true
        } catch let error as NSError {
            print("Cannot connect!")
            return false
        }
    }
    
    func saveRequest(userID: String, userFirstName: String, userLastName: String, description: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }

        let context = appDelegate.persistentContainer.viewContext
        
        if let entity = NSEntityDescription.entity(forEntityName: "Request", in: context) {

            let request = NSManagedObject(entity: entity, insertInto: context)

            let date = Date()
            let dateFormat = DateFormatter()
            dateFormat.dateFormat = "mm/dd/yyyy"
            let timeStamp = dateFormat.string(from: date)
            let status = "sent"
            
            request.setValue(userID, forKey: "userID")
            request.setValue(userFirstName, forKey: "userFirstName")
            request.setValue(userLastName, forKey: "userLastName")
            request.setValue(description, forKey: "request")
            request.setValue(timeStamp, forKey: "date")
            request.setValue(status, forKey: "status")
            
            do {
                try context.save()
                requests.append(request)
                print("Connected!")
                return true
            } catch let error as NSError {
                print("Cannot connect!")
                return false
            }
        }
        
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
            
        if retrieveData() {
            
            var requestText = ""
            
            for request in requests {
                
                if request.value(forKey: "userID") as! String == loginID && request.value(forKey: "status") as! String == "sent" {
                    
                    requestText += request.value(forKey: "request") as! String + " "
                    
                    requestText += request.value(forKey: "date") as! String + "\n"
                }
            }
            
            var responseText = ""
            
            for request in requests {
                
                if request.value(forKey: "userID") as! String == loginID && request.value(forKey: "status") as! String == "received" {
                    
                    requestText += request.value(forKey: "request") as! String + " "
                    
                    requestText += request.value(forKey: "date") as! String + "\n"
                }
            }
            
            lblRequestBox.text = requestText
        }
            
        else {
            lblMessageBox.text = "Error! Could not load data!"
        }
        
//        lblRequestBox.text = requestDB.getAllRequestsByUser(userID: loginID, status: "sent")
//
//        lblResponseBox.text = requestDB.getAllRequestsByUser(userID: loginID, status: "recieved")
//         Do any additional setup after loading the view.
    }

//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return }
//        let context = appDelegate.persistentContainer.viewContext
//    }
}
