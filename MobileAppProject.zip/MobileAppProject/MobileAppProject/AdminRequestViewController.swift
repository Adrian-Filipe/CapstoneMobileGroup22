//
//  AdminRequestViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class AdminRequestViewController: UIViewController {
    
    var requests:[NSManagedObject] = []
    
    @IBOutlet weak var lblRequestBox: UILabel!
    
    @IBOutlet weak var txtRequest: UITextField!

    @IBAction func btnSendReply(_ sender: UIButton) {
        
        lblMessageBox.text = ""
        
        //        let user = userDB.getUser(id: loginID)!
        
        if txtRequest.text != "" {
            
            //            if requestDB.addRequest(userID: loginID, user: user, request: txtRequest.text!) {
            if saveRequest(userID: txtRequest.text!, status: "received"){
                
                if retrieveData() {
                    
                    var requestText = ""
                    
                    for request in requests {
                        
                        if request.value(forKey: "status") as! String == "sent" {
                            
                            requestText += request.value(forKey: "userID") as! String + "\n"
                            
                            requestText += request.value(forKey: "firstName") as! String + " "
                            
                            requestText += request.value(forKey: "lastName") as! String + " "
                            
                            requestText += request.value(forKey: "request") as! String + " "
                            
                            requestText += request.value(forKey: "date") as! String + "\n"
                        }
                    }
                    
                    lblRequestBox.text = requestText
                    
                    lblMessageBox.text = "Reply sent!"
                }
                    
                else {
                    lblMessageBox.text = "Error! Could not load data!"
                }
                
                txtRequest.text = ""
            }
                
            else {
                lblMessageBox.text = "That request does not exist!"
            }
            
        }
    }
    
    @IBOutlet weak var lblMessageBox: UILabel!

    func retrieveData() -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        let connect = NSFetchRequest<NSManagedObject>(entityName: "Request")
        
        do {
            self.requests = try context.fetch(connect)
            print("Connected!")
            return true
        } catch let error as NSError {
            print("Cannot connect!")
            return false
        }
    }
    
    func saveRequest(userID: String, status: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        if let entity = NSEntityDescription.entity(forEntityName: "Request", in: context) {
            
            var changedStatus = false
            
            for request in requests {
                if request.value(forKey: "userID") as! String == userID {
                    
                    let request = NSManagedObject(entity: entity, insertInto: context)
                    
                    let date = Date()
                    let dateFormat = DateFormatter()
                    dateFormat.dateFormat = "mm/dd/yyyy"
                    let timeStamp = dateFormat.string(from: date)
                    let status = "received"
                    
                    request.setValue(timeStamp, forKey: "date")
                    request.setValue(status, forKey: "status")
                    
                    changedStatus = true
                }
            }
            
            if !changedStatus {
                return false
            }
            
            do {
                try context.save()
                print("Connected!")
                return true
            } catch let error as NSError {
                print("Cannot connect!")
                return false
            }
        }
        
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if retrieveData() {
            
            var requestText = ""
            
            for request in requests {
                
                if request.value(forKey: "status") as! String == "sent" {
                    
                    requestText += request.value(forKey: "userID") as! String + "\n"
                    
                    requestText += request.value(forKey: "userFirstName") as! String + " "
                    
                    requestText += request.value(forKey: "userLastName") as! String + " "
                    
                    requestText += request.value(forKey: "request") as! String + " "
                    
                    requestText += request.value(forKey: "date") as! String + "\n"
                }
            }
            
            lblRequestBox.text = requestText
        }
            
        else {
            lblMessageBox.text = "Error! Could not load data!"
        }
        
        //        lblRequestBox.text = requestDB.getAllRequestsByUser(userID: loginID, status: "sent")
        //
        //        lblResponseBox.text = requestDB.getAllRequestsByUser(userID: loginID, status: "recieved")
        //         Do any additional setup after loading the view.
    }
    
    //    override func viewWillAppear(_ animated: Bool) {
    //        super.viewWillAppear(animated)
    //        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return }
    //        let context = appDelegate.persistentContainer.viewContext
    //    }
}
