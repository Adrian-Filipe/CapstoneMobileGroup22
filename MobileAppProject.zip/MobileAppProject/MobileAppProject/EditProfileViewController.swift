//
//  EditProfileViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-05.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit

class EditProfileViewController: UIViewController {
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    @IBAction func btnConfirm(_ sender: UIButton) {
        userDB.editUser(id: loginID, firstName: txtFirstName.text!, lastName: txtLastName.text!, phone: txtPhone.text!, email: txtEmail.text!, password: txtPassword.text!)
        performSegue(withIdentifier: "ProfileEdited", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(userDB.getUser(id: loginID) != nil) {
            let user: User = userDB.getUser(id: loginID)!
            txtFirstName.text = user.getFirstName()
            txtLastName.text = user.getLastName()
            txtPhone.text = user.getPhone()
            txtEmail.text = user.getEmail()
            txtPassword.text = user.getPassword()
        }
            
        else {
            lblMessageBox.text = "Error! could not get data!"
        }
        
        // Do any additional setup after loading the view.
    }
}
