//
//  AdminEditProfileViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class AdminEditProfileViewController: UIViewController {
    
    var users:[NSManagedObject] = []
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    @IBAction func btnConfirm(_ sender: UIButton) {
        
        var message: String = ""
        
        message = validatePhoneEmailPassword(phone: txtPhone.text!, email: txtEmail.text!, password: txtPassword.text!)
        
        if message == "" {
            
            if saveUser() {
                performSegue(withIdentifier: "AdminProfileEdited", sender: self)
            }
                
            else {
                lblMessageBox.text = "Error! Could not save changes"
            }
        }
            
        else {
            lblMessageBox.text = message
        }
    }
    
    func retrieveData() -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        let connect = NSFetchRequest<NSManagedObject>(entityName: "User")
        
        do {
            self.users = try context.fetch(connect)
            print("Connected!")
            return true
        } catch let error as NSError {
            print("Cannot connect!")
            return false
        }
    }
    
    func saveUser() -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        if let entity = NSEntityDescription.entity(forEntityName: "User", in: context) {
            for user in users {
                if user.value(forKey: "userID") as! String == loginID {
                    user.setValue(txtFirstName.text!, forKey: "firstName")
                    user.setValue(txtLastName.text!, forKey: "lastName")
                    user.setValue(txtPhone.text!, forKey: "phone")
                    user.setValue(txtEmail.text!, forKey: "email")
                    user.setValue(txtPassword.text!, forKey: "password")
                }
            }
            
            do {
                try context.save()
                print("Connected!")
                return true
            } catch let error as NSError {
                print("Cannot connect!")
                return false
            }
        }
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if retrieveData() {
            
            for user in users {
                if user.value(forKey: "userID") as! String == loginID {
                    txtFirstName.text = user.value(forKey: "firstName") as! String
                    txtLastName.text = user.value(forKey: "lastName") as! String
                    txtPhone.text = user.value(forKey: "phone") as! String
                    txtEmail.text = user.value(forKey: "email") as! String
                    txtPassword.text = user.value(forKey: "password") as! String
                }
            }
        }
            
        else {
            lblMessageBox.text = "Error! could not get data!"
        }
        
        // Do any additional setup after loading the view.
    }
}
