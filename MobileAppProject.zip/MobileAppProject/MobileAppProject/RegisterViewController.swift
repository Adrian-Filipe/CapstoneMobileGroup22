//
//  RegisterViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-03-23.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class RegisterViewController: UIViewController {
    
    internal var users: [NSManagedObject] = []

    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var txtConfirmPassword: UITextField!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    @IBAction func btnRegister(_ sender: UIButton) {
        
        let message = validateRegistration(firstName: txtFirstName.text!, lastName: txtLastName.text!, phone: txtPhone.text!, email: txtEmail.text!, password: txtPassword.text!, confirmPassword: txtConfirmPassword.text!)
        
        if message == "" {
            if saveUser(firstName: txtFirstName.text!, lastName: txtLastName.text!, phone: txtPhone.text!, email: txtEmail.text!, password: txtPassword.text!) {
                
                performSegue(withIdentifier: "RegisterPassed", sender: self)
            }
            
            else {
                lblMessageBox.text = "Error! Could not create account!"
            }
        }
        
        else {
            lblMessageBox.text = message
        }
    }
    
    func saveUser(firstName: String, lastName: String, phone: String, email: String, password: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        if let entity = NSEntityDescription.entity(forEntityName: "User", in: context) {
            
            let user = NSManagedObject(entity: entity, insertInto: context)
            
            let userID = UUID().uuidString
            
            user.setValue(userID, forKey: "userID")
            user.setValue(firstName, forKey: "firstName")
            user.setValue(lastName, forKey: "lastName")
            user.setValue(phone, forKey: "phone")
            user.setValue(email, forKey: "email")
            user.setValue(password, forKey: "password")
            user.setValue("user", forKey: "role")
            
            do {
                try context.save()
                users.append(user)
                print("Connected!")
                return true
            } catch let error as NSError {
                print("Cannot connect!")
                return false
            }
        }
        
        return false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblMessageBox.text = ""
    }
}
