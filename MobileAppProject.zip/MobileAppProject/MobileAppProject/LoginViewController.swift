//
//  LoginViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-03-23.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class LoginViewController: UIViewController {
    
    internal var users: [NSManagedObject] = []
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    @IBAction func btnLogin(_ sender: UIButton) {
        var message:String = ""
        lblMessageBox.text = ""
        
        if txtEmail.text == "" {
            message = "Email field cannot be empty!"
        }
        
        else if txtPassword.text == "" {
            message = "Password field cannot be empty!"
        }
        
        else {
            if retrieveData() {
                var validated = false
                
                for user in users {
                    if txtEmail.text == user.value(forKeyPath: "email") as? String && txtPassword.text == user.value(forKeyPath: "password") as? String {
                        validated = true
                    }
                }
                
                if !validated {
                    message = "Email or Password is incorrect!"
                }
            }
            
            else {
                message = "Error! Could not connect!"
            }
        }
        
        if message == "" {
            
            for user in users {
                if txtEmail.text == user.value(forKeyPath: "email") as? String && txtPassword.text == user.value(forKeyPath: "password") as? String {
                    
                    loginID = user.value(forKeyPath: "userID") as! String
                    loginFirstName = user.value(forKeyPath: "firstName") as! String
                    loginLastName = user.value(forKeyPath: "lastName") as! String
                    
                    if user.value(forKeyPath: "role") as! String == "admin" {
                        performSegue(withIdentifier: "AdminLoginPassed", sender: self)
                    }
                        
                    else {
                        performSegue(withIdentifier: "LoginPassed", sender: self)
                    }
                }
                
            }
        }
        
        else {
            lblMessageBox.text = message
        }
    }
    
    func retrieveData() -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        let connect = NSFetchRequest<NSManagedObject>(entityName: "User")
        
        do {
            self.users = try context.fetch(connect)
            print("Connected!")
            return true
        } catch let error as NSError {
            print("Cannot connect!")
            return false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblMessageBox.text = ""
    }
    
    
}
