//
//  AdminProfileViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class AdminProfileViewController: UIViewController {
    
    var users:[NSManagedObject] = []
    
    @IBOutlet weak var lblFirstName: UILabel!
    
    @IBOutlet weak var lblLastName: UILabel!
    
    @IBOutlet weak var lblPhone: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var lblPassword: UILabel!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    func retrieveData() -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        let connect = NSFetchRequest<NSManagedObject>(entityName: "User")
        
        do {
            self.users = try context.fetch(connect)
            print("Connected!")
            return true
        } catch let error as NSError {
            print("Cannot connect!")
            return false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if retrieveData() {
            
            for user in users {
                if user.value(forKey: "userID") as! String == loginID {
                    lblFirstName.text = user.value(forKey: "firstName") as! String
                    lblLastName.text = user.value(forKey: "lastName") as! String
                    lblPhone.text = user.value(forKey: "phone") as! String
                    lblEmail.text = user.value(forKey: "email") as! String
                    lblPassword.text = user.value(forKey: "password") as! String
                }
            }
        }
            
        else {
            lblMessageBox.text = "Error! could not get data!"
        }
        // Do any additional setup after loading the view.
    }
}
