//
//  AdminProfileViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit

class AdminProfileViewController: UIViewController {
    
    @IBOutlet weak var lblFirstName: UILabel!
    
    @IBOutlet weak var lblLastName: UILabel!
    
    @IBOutlet weak var lblPhone: UILabel!
    
    @IBOutlet weak var lblEmail: UILabel!
    
    @IBOutlet weak var lblPassword: UILabel!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(userDB.getUser(id: loginID) != nil) {
            let user: User = userDB.getUser(id: loginID)!
            lblFirstName.text = user.getFirstName()
            lblLastName.text = user.getLastName()
            lblPhone.text = user.getPhone()
            lblEmail.text = user.getEmail()
            lblPassword.text = user.getPassword()
        }
            
        else {
            lblMessageBox.text = "Error! could not get data!"
        }
        // Do any additional setup after loading the view.
    }
}
