////
////  RequestManager.swift
////  MobileAppProject
////
////  Created by Tech on 2021-04-07.
////  Copyright © 2021 Meghan Paris. All rights reserved.
////
//
//import Foundation
//
//class RequestManager {
//    private var requestsList: [Request]
//
//    init() {
//        self.requestsList = []
//    }
//
//    public func addRequest(userID: Int, user: User, request: String) -> Bool {
//        requestsList.append(Request(userID: userID, user: user, request: request))
//        return true
//    }
//
//    public func getAllRequestsByUser(userID: Int, status: String) -> String {
//        var text = ""
//        for request in requestsList {
//            if userID == request.getUserID() && status == request.getStatus() {
//                text += request.getRequest() + "\t" + request.getDate() + "\n"
//            }
//        }
//
//        return text
//    }
//}
//
//var requestDB = RequestManager()
