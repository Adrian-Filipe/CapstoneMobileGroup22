//
//  Logined.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-05.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import CoreData

var loginID: String = ""
var loginFirstName: String = ""
var loginLastName: String = ""
