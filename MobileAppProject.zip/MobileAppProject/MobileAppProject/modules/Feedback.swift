//
//  Feedback.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-14.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation

class Feedback {
    private var userID: String
    private var title: String
    private var description: String
    private var timeStamp: String
    private var status: String
    
    init(userID: String, title: String, description: String) {
        self.userID = userID
        self.title = title
        self.description = description
        let date = Date()
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "mm/dd/yyyy"
        self.timeStamp = dateFormat.string(from: date)
        self.status = "sent"
    }
    
    public func getUserID() -> String {
        return self.userID
    }
    
    public func getTitle() -> String {
        return self.title
    }
    
    public func getDescription() -> String {
        return self.description
    }
    
    public func getTimeStamp() -> String {
        return self.timeStamp
    }
    
    public func getStatus() -> String {
        return self.status
    }
    
    public func changeStatus(newStatus: String) {
        self.status = newStatus
    }
}
