//
//  FeedbackManager.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-14.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation

class FeedbackManager {
    private var feedbacksList: [Feedback]
    
    init() {
        self.feedbacksList = []
    }
    
    public func addFeedback(userID: String, title: String, description: String) -> Bool {
        feedbacksList.append(Feedback(userID: userID, title: title, description: description))
        return true
    }
    
    public func getAllFeedbacksByUser(userID: String, status: String) -> String {
        var text = ""
        for feedback in feedbacksList {
            if userID == feedback.getUserID() && status == feedback.getStatus() {
                text += feedback.getTitle() + "\n" + feedback.getDescription() + "\n" + feedback.getTimeStamp() + "\n"
            }
        }
        
        return text
    }
    
    public func getAllFeedback() -> String {
        var text = ""
        for feedback in feedbacksList {
            text += feedback.getTitle() + "\n" + feedback.getDescription() + "\n" + feedback.getTimeStamp() + "\n"
        }
        
        return text
    }
}

var feedbackDB = FeedbackManager()
