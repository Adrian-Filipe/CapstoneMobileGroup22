////
////  User.swift
////  MobileAppProject
////
////  Created by Tech on 2021-03-24.
////  Copyright © 2021 Meghan Paris. All rights reserved.
////
//
//import Foundation
//
//class User {
//    private var firstName: String
//    private var lastName: String
//    private var phone: String
//    private var email: String
//    private var password: String
//    private var role: String
//
//    init(firstName: String, lastName: String, phone: String, email: String, password: String, role: String) {
//        self.firstName = firstName
//        self.lastName = lastName
//        self.phone = phone
//        self.email = email
//        self.password = password
//        self.role = role
//    }
//
//    public func getFirstName() -> String {
//        return self.firstName
//    }
//
//    public func getLastName() -> String {
//        return self.lastName
//    }
//
//    public func getPhone() -> String {
//        return self.phone
//    }
//
//    public func getEmail() -> String {
//        return self.email
//    }
//
//    public func getPassword() -> String {
//        return self.password
//    }
//
//    public func getRole() -> String {
//        return self.role
//    }
//
//    public func setFirstName(firstName: String) -> Bool {
//        self.firstName = firstName
//        return true
//    }
//
//    public func setLastName(lastName: String) -> Bool {
//        self.lastName = lastName
//        return true
//    }
//
//    public func setPhone(phone: String) -> Bool {
//        self.phone = phone
//        return true
//    }
//
//    public func setEmail(email: String) -> Bool {
//        self.email = email
//        return true
//    }
//
//    public func setPassword(password: String) -> Bool {
//        self.password = password
//        return true
//    }
//
//    public func setRole(role: String) -> Bool {
//        self.role = role
//        return true
//    }
//}
//
