//
//  database.swift
//  MobileAppProject
//
//  Created by Tech on 4/18/21.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import CoreData

func retrieveData() -> Bool {
    guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
    
    let context = appDelegate.persistentContainer.viewContext
    
    let connect = NSFetchRequest<NSManagedObject>(entityName: "User")
    
    do {
        self.users = try context.fetch(connect)
        print("Connected!")
        return true
    } catch let error as NSError {
        print("Cannot connect!")
        return false
    }
}
