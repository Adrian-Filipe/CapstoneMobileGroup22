////
////  Request.swift
////  MobileAppProject
////
////  Created by Tech on 2021-04-07.
////  Copyright © 2021 Meghan Paris. All rights reserved.
////
//
//import Foundation
//
//class Request {
//    private var userID: Int
//    private var user: User
//    private var request: String
//    private var date: String
//    private var status: String
//
//    init(userID: Int, user: User, request: String) {
//        self.userID = userID
//        self.user = user
//        self.request = request
//        let date = Date()
//        let dateFormat = DateFormatter()
//        dateFormat.dateFormat = "mm/dd/yyyy"
//        self.date = dateFormat.string(from: date)
//        self.status = "sent"
//    }
//
//    public func getUserID() -> Int {
//        return self.userID
//    }
//
//    public func getUser() -> User {
//        return self.user
//    }
//
//    public func getRequest() -> String {
//        return self.request
//    }
//
//    public func getDate() -> String {
//        return self.date
//    }
//
//    public func getStatus() -> String {
//        return self.status
//    }
//
//    public func changeStatus(newStatus: String) {
//        self.status = newStatus
//    }
//}
