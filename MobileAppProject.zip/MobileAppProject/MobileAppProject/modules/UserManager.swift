////
////  UserManager.swift
////  MobileAppProject
////
////  Created by Tech on 2021-03-25.
////  Copyright © 2021 Meghan Paris. All rights reserved.
////
//
//import Foundation
//
//class UserManager {
//    private var usersList: [User]
//
//    init() {
//        self.usersList = []
//    }
//
//    public func addUser(firstName: String, lastName: String, phone: String, email: String, password: String, role: String) -> Bool {
//        usersList.append(User(firstName: firstName, lastName: lastName, phone: phone, email: email, password: password, role: role))
//        return true
//    }
//
//    public func findUser(email: String, password: String) -> Int {
//        for i in 0...usersList.count - 1 {
//            if usersList[i].getEmail() == email && usersList[i].getPassword() == password {
//                return i
//            }
//        }
//        return -1
//    }
//
//    public func getUser(id: Int) -> User? {
//        for i in 0...usersList.count - 1 {
//            if id == i {
//                return usersList[i]
//            }
//        }
//        return nil
//    }
//
//    public func editUser(id: Int, firstName: String, lastName: String, phone: String, email: String, password: String) -> Bool {
//        usersList[id].setFirstName(firstName: firstName)
//        usersList[id].setLastName(lastName: lastName)
//        usersList[id].setPhone(phone: phone)
//        usersList[id].setEmail(email: email)
//        usersList[id].setPassword(password: password)
//        return true
//    }
//
//    public func checkUserRole(id: Int) -> String {
//        let user = self.getUser(id: id)!
//        if user.getRole() == "admin" {
//            return "admin"
//        }
//        return "user"
//    }
//}
//
//var userDB = UserManager()
