//
//  validation.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-14.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation

func validateRegistration(firstName: String, lastName: String, phone: String, email: String, password: String, confirmPassword: String) -> String {
    var message: String = ""
    
    if firstName == "" || lastName == "" || phone == "" || email == "" || password == "" || confirmPassword == ""{
        message = "One or more of the above fields is missing"
        return message
    }
    
    message = validatePhoneEmailPassword(phone: phone, email: email, password: password)
    
    if message != "" {
        return message
    }
    
    if password != confirmPassword {
        message = "Both password fields do not match!"
        return message
    }
    
//    userDB.addUser(firstName: firstName, lastName: lastName, phone: phone, email: email, password: password, role: "user")
    
    return ""
}

func validatePhoneEmailPassword(phone: String, email: String, password: String) -> String {
    var message: String = ""
    var passwordValidated:Bool = false
    var index:Int = 0
    var isNumber:Bool = false
    var isUnderscore:Bool = false
    for char in phone {
        index += 1
        for i in 0...9 {
            if String(char) == String(i) && index != 4 && index != 8{
                isNumber = true
            }
        }
        
        if String(char) == "-" && index == 4 || String(char) == "-" && index == 8 {
            isUnderscore = true
        }
        
        if !isNumber && !isUnderscore || phone.count != 12 {
            message = "Phone number is invalid, should follow this format 999-999-9999"
        }
        
        isNumber = false
        isUnderscore = false
    }
    
    if message != "" {
        return message
    }
        
    else {
        var counterOne:Int = 0
        var counterTwo:Int = 0
        for char in email {
            index += 1
            if char == "@" {
                counterOne += 1
            }
            else if char == "." {
                counterTwo += 1
            }
            
        }
        if counterOne != 1 || counterTwo != 1 {
            message = "Email is invalid, should have @ and .domain"
            return message
        }
    }
    
    if message != "" {
        return message
    }
        
    else {
        var isUpperCase:Bool = false
        var isLowerCase:Bool = false
        isNumber = false
        var isSpceialCharacter:Bool = false
        if password.count >= 8 {
            for char in password {
                if char.asciiValue! >= 65 && char.asciiValue! <= 90 {
                    isUpperCase = true
                }
                
                if char.asciiValue! >= 97 && char.asciiValue! <= 122 {
                    isLowerCase = true
                }
                
                if char.asciiValue! >= 48 && char.asciiValue! <= 57 {
                    isNumber = true
                }
                
                if char.asciiValue! < 65 || char.asciiValue! > 90 && char.asciiValue! < 97 || char.asciiValue! > 122 && char.asciiValue! < 48 || char.asciiValue! > 57 {
                    isSpceialCharacter = true
                }
                
                if isUpperCase && isLowerCase && isNumber && isSpceialCharacter {
                    passwordValidated = true
                    break
                }
            }
        }
    }
    
    if !passwordValidated {
        if message == "" {
            message = "Password is invalid, should have minimum 8 characters, atleast 1 uppercase, lowercase, number, and special character"
            return message
        }
    }
    
    return ""
}
