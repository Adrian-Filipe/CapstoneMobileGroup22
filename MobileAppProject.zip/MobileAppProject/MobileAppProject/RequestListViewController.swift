//
//  RequestViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-07.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class RequestListViewController: UITableViewController {
    
    var requests:[NSManagedObject] = []
    
    func saveRequest(userID: String, userFirstName: String, userLastName: String, description: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return false }
        
        let context = appDelegate.persistentContainer.viewContext
        
        if let entity = NSEntityDescription.entity(forEntityName: "Request", in: context) {
            
            let request = NSManagedObject(entity: entity, insertInto: context)
            
            let date = Date()
            let dateFormat = DateFormatter()
            dateFormat.dateFormat = "mm/dd/yyyy"
            let timeStamp = dateFormat.string(from: date)
            let status = "sent"
            
            request.setValue(userID, forKey: "userID")
            request.setValue(userFirstName, forKey: "userFirstName")
            request.setValue(userLastName, forKey: "userLastName")
            request.setValue(description, forKey: "request")
            request.setValue(timeStamp, forKey: "date")
            request.setValue(status, forKey: "status")
            
            do {
                try context.save()
                requests.append(request)
                print("Connected!")
                return true
            } catch let error as NSError {
                print("Cannot connect!")
                return false
            }
        }
        
        return false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return }
        
        let context = appDelegate.persistentContainer.viewContext
        
        let connect = NSFetchRequest<NSManagedObject>(entityName: "Request")
        
        do {
            requests = try context.fetch(connect)
            print("Connected!")
        } catch let error as NSError {
            print("Cannot connect!")
        }
        
        tableView.reloadData()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return requests.count
        }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let request = requests[indexPath.row]
        
        cell.textLabel?.text = (request.value(forKey: "request") as! String)
        
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //        lblRequestBox.text = requestDB.getAllRequestsByUser(userID: loginID, status: "sent")
        //
        //        lblResponseBox.text = requestDB.getAllRequestsByUser(userID: loginID, status: "recieved")
        //         Do any additional setup after loading the view.
    }
    
    //    override func viewWillAppear(_ animated: Bool) {
    //        super.viewWillAppear(animated)
    //        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{ return }
    //        let context = appDelegate.persistentContainer.viewContext
    //    }
}
