//
//  FeedbackViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-14.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit

class FeedbackViewController: UIViewController {
    
    @IBOutlet weak var txtTitle: UITextField!
    
    @IBOutlet weak var txtDescription: UITextView!
    
    @IBAction func btnSend(_ sender: UIButton) {
        
        lblMessageBox.text = ""
        
        if txtTitle.text != "" && txtDescription.text != "" {
            
            if feedbackDB.addFeedback(userID: loginID, title: txtTitle.text!, description: txtDescription.text!){
                
                lblMessageBox.text = "Feedback sent!"
                
                txtTitle.text = ""
                txtDescription.text = ""
            }
                
            else {
                lblMessageBox.text = "Error! Could not send feedback"
            }
            
        }
    }
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
