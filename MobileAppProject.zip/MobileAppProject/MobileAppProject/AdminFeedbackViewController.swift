//
//  AdminFeedbackViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-04-14.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit

class AdminFeedbackViewController: UIViewController {
    
    @IBOutlet weak var lblFeedbackList: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lblFeedbackList.text! =  feedbackDB.getAllFeedback()
        // Do any additional setup after loading the view.
    }
}
