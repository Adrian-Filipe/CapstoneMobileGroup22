//
//  UserManager.swift
//  MobileAppProject
//
//  Created by Tech on 2021-03-25.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation

class UserManager {
    private var usersList: [User]
    
    init() {
        self.usersList = []
    }
    
    public func addUser(firstName: String, lastName: String, phone: String, email: String, password: String) -> Bool {
        usersList.append(User(firstName: firstName, lastName: lastName, phone: phone, email: email, password: password))
        return true
    }
    
    public func findUser(email: String, password: String) -> Bool {
        for user in usersList {
            if user.getEmail() == email && user.getPassword() == password {
                return true
            }
        }
        return false
    }
}

var userDB = UserManager()
