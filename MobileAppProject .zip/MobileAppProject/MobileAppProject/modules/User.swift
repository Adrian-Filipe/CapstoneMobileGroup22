//
//  User.swift
//  MobileAppProject
//
//  Created by Tech on 2021-03-24.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation

class User {
    private var firstName: String
    private var lastName: String
    private var phone: String
    private var email: String
    private var password: String
    
    init(firstName: String, lastName: String, phone: String, email: String, password: String) {
        self.firstName = firstName
        self.lastName = lastName
        self.phone = phone
        self.email = email
        self.password = password
    }
    
    public func getFirstName() -> String {
        return self.firstName
    }
    
    public func getLastName() -> String {
        return self.lastName
    }
    
    public func getPhone() -> String {
        return self.phone
    }
    
    public func getEmail() -> String {
        return self.email
    }
    
    public func getPassword() -> String {
        return self.password
    }
}
