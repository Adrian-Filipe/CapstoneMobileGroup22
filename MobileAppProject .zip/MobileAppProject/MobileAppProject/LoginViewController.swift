//
//  LoginViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-03-23.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    @IBAction func btnLogin(_ sender: UIButton) {
        var message:String = ""
        lblMessageBox.text = ""
        
        if txtEmail.text == "" {
            message = "Email field cannot be empty!"
        }
        
        else if txtPassword.text == "" {
            message = "Password field cannot be empty!"
        }
        
        else if !userDB.findUser(email: txtEmail.text!, password: txtPassword.text!) {
            message = "Email or Password is incorrect!"
        }
        
        if message == "" {
            performSegue(withIdentifier: "LoginPassed", sender: self)
        }
        
        else {
            lblMessageBox.text = message
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblMessageBox.text = ""
    }
    
    
}
