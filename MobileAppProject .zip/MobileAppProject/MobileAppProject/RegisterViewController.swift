//
//  RegisterViewController.swift
//  MobileAppProject
//
//  Created by Tech on 2021-03-23.
//  Copyright © 2021 Meghan Paris. All rights reserved.
//

import Foundation
import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtPhone: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var txtConfirmPassword: UITextField!
    
    @IBOutlet weak var lblMessageBox: UILabel!
    
    @IBAction func btnRegister(_ sender: UIButton) {
        var message:String = ""
        lblMessageBox.text = ""
        
        if txtFirstName.text == "" || txtLastName.text == "" || txtPhone.text == "" || txtEmail.text == "" || txtPassword.text == "" || txtConfirmPassword.text == ""{
            message = "One or more of the above fields is missing"
            lblMessageBox.text = message
        }
            
        else {
            let phone:String = txtPhone.text!
            let email:String = txtEmail.text!
            let password:String = txtPassword.text!
            var passwordValidated:Bool = false
            var index:Int = 0
            var isNumber:Bool = false
            var isUnderscore:Bool = false
            for char in phone {
                index += 1
                for i in 0...9 {
                    if String(char) == String(i) && index != 4 && index != 8{
                        isNumber = true
                    }
                }
                
                if String(char) == "-" && index == 4 || String(char) == "-" && index == 8 {
                    isUnderscore = true
                }
                
                if !isNumber && !isUnderscore || phone.count != 12 {
                    message = "Phone number is invalid, should follow this format 999-999-9999"
                }
                
                isNumber = false
                isUnderscore = false
            }
            
            if message != "" {
                lblMessageBox.text = message
            }

            else {
                var counterOne:Int = 0
                var counterTwo:Int = 0
                for char in email {
                    index += 1
                    if char == "@" {
                        counterOne += 1
                    }
                    else if char == "." {
                        counterTwo += 1
                    }
                    
                }
                if counterOne != 1 || counterTwo != 1 {
                    message = "Email is invalid, should have @ and .domain"
                    lblMessageBox.text = message
                }
            }
            
            if message != "" {
                lblMessageBox.text = message
            }
            
            else {
                var isUpperCase:Bool = false
                var isLowerCase:Bool = false
                isNumber = false
                var isSpceialCharacter:Bool = false
                if password.count >= 8 {
                    for char in password {
                        if char.asciiValue! >= 65 && char.asciiValue! <= 90 {
                            isUpperCase = true
                        }
                        
                        if char.asciiValue! >= 97 && char.asciiValue! <= 122 {
                            isLowerCase = true
                        }
                        
                        if char.asciiValue! >= 48 && char.asciiValue! <= 57 {
                            isNumber = true
                        }
                        
                        if char.asciiValue! < 65 || char.asciiValue! > 90 && char.asciiValue! < 97 || char.asciiValue! > 122 && char.asciiValue! < 48 || char.asciiValue! > 57 {
                            isSpceialCharacter = true
                        }
                        
                        if isUpperCase && isLowerCase && isNumber && isSpceialCharacter {
                            passwordValidated = true
                            break
                        }
                    }
                }
            }
            
            if !passwordValidated {
                if message == "" {
                    message = "Password is invalid, should have minimum 8 characters, atleast 1 uppercase, lowercase, number, and special character"
                    lblMessageBox.text = message
                }
            }
            
            else {
                if txtPassword.text != txtConfirmPassword.text {
                    message = "Both password fields do not match!"
                    lblMessageBox.text = message
                }
            }
        }
        
        if message == "" {
            userDB.addUser(firstName: txtFirstName.text!, lastName: txtLastName.text!, phone: txtPhone.text!, email: txtEmail.text!, password: txtPassword.text!)
            performSegue(withIdentifier: "RegisterPassed", sender: self)
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblMessageBox.text = ""
    }
}
